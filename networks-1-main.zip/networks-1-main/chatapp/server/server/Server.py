from json import dumps, load
from socket import *
import threading
from os.path import exists
from typing import Tuple

from .Group import Group
from .Client import Client
from ...utils.datagram import STATUS, DATA, Request, Response, decode

class Server:
	"""
	A Class representing the server application
	-------------------------------------------
	The server class represents the server application running on the server. It is responsible for
	responding to Requests from clients and forwarding messages from one client to another.

	It has a client object for each client that has signed up which is responsible for managing the
	queing and sendng of messages to that client. When that client comes online their client object
	is set to online and messages to them will be forwarded to them instead of stored.

	The server has a dictionary of all the usernames people have siged up with, where the key is the
	number of users that have signed up with that username. This is how it is able to provide a
	unique name for every user even if users sign up with the same name.

	When a user comes online, either by signing up or logging in their sending ip:port and recieving
	ip:port are added to the requestAddrs and responseAddrs maps with their username as the value.
	Using this the server can determin the username of the sender on subsequent requests without the
	sender having to include it in every packet.

	### Arguments
	`port: int` - The port to start the server on.
	"""
	dataPath = "./chatapp/server/data/"

	def __init__(this, port: int):
		this.socket = socket(AF_INET, SOCK_DGRAM)
		this.socket.bind(("", port))
		this.listening = False
		this.usernames: dict[str, str] = Server.loadFile("usernames")
		this.clients: dict[str, Client] = this.loadClients("clients")
		this.requestAddrs: dict[str, str] = {}
		this.responseAddrs: dict[str, str]= {}
		this.groups: dict[str, Group] = {}
		this.auth: list[function] = [this.signUp, this.logIn]
		this.ctrl: list[function] = [this.startChat, this.startGroup, this.joinGroup, this.leaveGroup, this.logOut]
		this.data: list[function] = [this.msg, None, this.read]
		this.request: dict[str, list[function]] = {"AUTH": this.auth, "CTRL": this.ctrl, "DATA": this.data}
		this.TEST = True
	
	def start(this):
		"""
		Start listening for incoming requests form clients.

		This method is blocking and should be called on a new thread.
		`Returns: void`
		"""
		this.listening = True
		try:
			print("Server listening")
			while this.listening:
				msg, addr = this.socket.recvfrom(2048)
				threading.Thread(target=this.handlePacket, args=(msg, addr)).start()
		# Error thrown when socket is closed
		except OSError:	pass
	
	def handlePacket(this, b: bytes, addr: Tuple[str, int]):
		"""
		This method is called on a new thread each time the server receives a packet. It determines
		if the packet is a request or response, and then calls the appropritate handler. If the
		message is corrupt nothing is done, as it is the responsibility of the client to resend the
		message if it doesn't receive a response.

		### Arguments
		`b: bytes` - The message bytes
		`addr: (str, int)` - The address of the sender

		`Returns: void`
		"""
		# If the message was a ping just send a single byte back
		if len(b) == 1: return this.socket.sendto("p".encode(), addr)
		msg = decode(b)
		if msg.corrupt:
			print("CORRUPT MESSAGE FROM", addr)
			# res = Response(STATUS.BAD_REQUEST, seq=msg.header["seq"])
			# this.socket.sendto(res.encode(), addr)
		elif type(msg) == Request:
			this.handleRequest(msg, addr)
		elif type(msg) == Response:
			this.handleResponse(msg, addr)
	
	def handleRequest(this, msg: Request, addr: Tuple[str, int]):
		"""
		Process incoming requests by calling the corresponding function from the array for the
		request's command. and sending the response. The functions for each command type have the
		same signiture.

		### Arguments
		`msg: Request` - The request to handle
		`addr: (str, int)` - The address of the sender

		`Returns: void`
		"""
		res: Response = None
		try:
			address = f"{addr[0]}:{addr[1]}"
			if msg.command == "AUTH":
				res = this.request["AUTH"][msg.header["type"]](msg.header["sender"], msg.body, msg.header["seq"], address)
			elif address in this.requestAddrs:
				sender = this.clients[this.requestAddrs.get(address)]
				sender.seen()
				if msg.command == "CTRL":
					res = this.request["CTRL"][msg.header["type"]](msg.body, msg.header["seq"], address)
				else:
					res = this.request["DATA"][msg.header["type"]](sender.username, msg.header["recipient"], msg.body, msg.header["sent"], msg.header["seq"])
			else:
				res = Response(STATUS.NO_AUTH, seq=msg.header["seq"])
		except:
			# This shouldn't ever have to run
			print("BAD REQUEST")
			res = Response(STATUS.BAD_REQUEST, seq=msg.header["seq"])
		if res:
			this.socket.sendto(res.encode(), addr)
	
	def handleResponse(this, msg: Response, addr: Tuple[str, int]):
		"""
		Process incoming responses by dequeuing the correspondiing request and queueing a request to
		a receiving client where neccessary.

		### Arguments
		`msg: Response` - The response to handle
		`addr: (str, int)` - The address of the sender

		`Returns: void`
		"""
		address = f"{addr[0]}:{addr[1]}"
		if address in this.responseAddrs:
			client = this.clients[this.responseAddrs[address]]
			if not msg.corrupt and msg.status == STATUS.OK:
				req = client.dequeue(msg.header["seq"])
				# if there was a msg in q corresponding to the response, from another user,
				# send user received reciept as it was from a user not a group
				if req and "#" in req.header["sender"] and req.header["type"] == DATA.MSG:
					this.clients[req.header["sender"].lower()].enqueue(DATA.RECEIVED, client.username, req.header["sent"], None)
			else:
				client.resend()
		else:
			# this branch only occurs when server receives a response from an offline client
			pass

#              _   _     
#             | | | |    
#   __ _ _   _| |_| |__  
#  / _` | | | | __| '_ \ 
# | (_| | |_| | |_| | | |
#  \__,_|\__,_|\__|_| |_|

	def signUp(this, sender: str, body: Tuple[str, int], seq: int, addr: str):
		"""
		Sign ap a new user by generating a tag number for them, creating a new client object.

		### Arguments
		`sender: str` - The username the client who sent the AUTH request would like to use.
		`body: [str, int]` - The address the new client would like the server to send requests to
		for this session.
		`seq: int` - The sequence number of the request. 0 because it is an AUTH request
		`addr: str` - The ip:port that the user will be sending messages to the server from this
		session. Used to recognise which user further requests are coming from.

		`Returns: Response` - The response to send to the client
		"""
		user = sender.lower()
		tag = this.usernames.get(user, 0) + 1
		this.usernames[user] = tag
		username = f"{sender}#{tag:0>4}"
		this.clients[username.lower()] = Client(this, username=username, addr=addr, sendAddr=body, online=True)
		print(addr, "signed up as", username)
		return Response(STATUS.OK, seq=seq, body=str(tag))

	def logIn(this, sender: str, body: Tuple[str, int], seq: int, addr: str):
		"""
		Log an existing user in by marking them as online, adding their request and response
		addresses to the relevant lookup tables. Marking them as online lets their client object on
		the server know it can start forwarding them their messages if they have any from while they
		were offline.

		### Arguments
		`sender: str` - The username of the client who sent the AUTH request.
		`body: [str, int]` - The address the client would like the server to send requests to for
		this session.
		`seq: int` - The sequence number of the request. 0 because it is an AUTH request
		`addr: str` - The ip:port that the user will be sending messages to the server from this
		session. Used to recognise which user further requests are coming from.

		`Returns: Response` - The response to send to the client
		"""
		if (sender in this.clients):
			this.clients[sender].online(addr, body)
			res = Response(STATUS.OK, seq=seq)
		else:
			res = Response(STATUS.NOT_FOUND, seq=seq)
		return res
#       _        _ 
#      | |      | |
#   ___| |_ _ __| |
#  / __| __| '__| |
# | (__| |_| |  | |
#  \___|\__|_|  |_|

	def startChat(this, body: str, seq: int, addr: str):
		"""
		Check whether a client exists in the "database" and let the user know if they do or don't so
		they can start a chat with them.

		### Arguments
		`body: str` - The username of the client the sender of the CTRL request wants to start a
		chat with.
		`seq: int` - The sequence number of this request
		`addr: str` - The ip:port of the client that sent the request, used to get their username
		from the lookup table.

		`Returns: Response` - The response to send to the client
		"""
		if(body in this.clients):
			res = Response(STATUS.OK, seq=seq, body=this.clients[body].username)
			print(this.requestAddrs.get(addr), "+", body)
		else:
			res = Response(STATUS.NOT_FOUND, seq=seq)
			print("User", body, "does not exist")
		return res

	def startGroup(this, body: str, seq: int, addr: str):
		"""
		Not used, didn't have time to finish groups
		-------------------------------------------
		Start a group by creating a new group object, adding it to the map of groups and adding the
		group to the client's list of groups.

		### Arguments
		`body: str` - The name of the new Group
		`seq: int` - The sequence number of this request
		`addr: str` - The ip:port of the client that sent the request, used to get their username
		from the lookup table.
		
		`Returns: Response` The body of the response is the id of the new group
		"""
		username = this.requestAddrs.get(addr)
		group = Group(this, username, body)
		this.clients[username].groups.add(group)
		this.groups[group.id] = group
		res = Response(STATUS.OK, seq=seq, body=group.id)
		return res

	def joinGroup(this, body: str, seq: int, addr: str):
		"""
		Not used, didn't have time to finish groups
		-------------------------------------------
		Join a group if it exists and isn't at capacity

		### Arguments
		`body: str` - The id of the group the sender wishes to join
		`seq: int` - The sequence number of this request
		`addr: str` - The ip:port of the client that sent the request, used to get their username
		from the lookup table.

		`Returns: Response` - the body of the response, if successful, is the name of the group
		"""
		if (body in this.groups):
			username = this.requestAddrs.get(addr)
			group = this.groups.get(body)
			joined = group.join(username)
			if joined:
				res = Response(STATUS.OK, seq=seq, body=group.name)
			else:
				res = Response(STATUS.DENIED, seq=seq, body=group.name)
		else:
			res = Response(STATUS.NOT_FOUND, seq=seq)
		return res

	def leaveGroup(this, body: str, seq: int, addr: str):
		"""
		Not used, didn't have time to finish groups
		-------------------------------------------
		Leave a group and delete the group if there is no one left in it

		### Arguments
		`body: str` - The id of the group the sender wishes to leave
		`seq: int` - The sequence number of this request
		`addr: str` - The ip:port of the client that sent the request, used to get their username
		from the lookup table.

		`Returns: Response` - The response sent to the client
		"""
		username = this.requestAddrs.get(addr)
		this.groups[body].leave(username)
		this.clients[username].groups.pop(this.groups[body])
		return Response(STATUS.OK, seq=seq)
	
	def logOut(this, body: str, seq: int, addr: str):
		"""
		Mark the sender as offline. This involves setting a flag in their object to offline,
		removing their send and receive addresses from the lookup maps and serializing any requests
		in their queue so they can be written to file.

		### Arguments
		`body: str` - Not used
		`seq: int` - Not used
		`addr: str` - The ip:port of the client that sent the request, used to get their username
		from the lookup table.

		`Returns: void`
		"""
		this.clients[this.requestAddrs[addr]].offline()

#      _       _        
#     | |     | |       
#   __| | __ _| |_ __ _ 
#  / _` |/ _` | __/ _` |
# | (_| | (_| | || (_| |
#  \__,_|\__,_|\__\__,_|

	def msg(this, sender: str, recipient: str, body: str, sent: int, seq: int):
		"""
		Send a message to a client or group. The message is put in the queue of the recipient, or in
		the queues of the groups participants (excluding the sender).

		### Arguments
		`sender: str` - The client who sent the message
		`recipient: str` - The group id or username to forward the message to
		`body: str` - The message itself
		`sent: int` - The time the message was sent by the client
		`seq: int` - The sequence number of this request

		`Returns: Response | void` - If the message is to a valid user the body of the response is 
		the timestamp of the message so that the client can mark it as received by the server. If it
		is to an invalid user or group a NOT_FOUND response is sent. If it is to a valid group no
		response is sent as messages to groups don't require responses.
		"""
		if ("#" in recipient):
			if recipient in this.clients:
				client = this.clients[recipient]
				client.enqueue(DATA.MSG, sender, body, sent)
				res = Response(STATUS.OK, seq=seq, body=sent)
			else:
				res = Response(STATUS.NOT_FOUND, seq=seq)
		else:
			if recipient in this.groups:
				#todo send group message
				for member in this.groups[recipient].members:
					if member != sender:
						this.clients[member].enqueue(DATA.MSG, sender, body, sent, recipient)
			else:
				res = Response(STATUS.NOT_FOUND, seq=seq)
		return res

	def read(this, sender: str, recipient: str, body: str, sent: int, seq: int):
		"""
		Forward a read response from one client to another letting the receiver know that their
		message(s) up until the message with the given timestamp have been read by the sender.

		### Arguments
		`sender: str` - The client who sent the message
		`recipient: str` - The client to forward the read message to
		`body: str` - Not used
		`sent: int` - The timestamp that of the last message in the chat that was read.
		`seq: int` - The sequence number of this request.

		`Returns: Response` - The response sent to the client
		"""
		this.clients[recipient].enqueue(DATA.READ, sender, sent, None)
		return Response(STATUS.OK, seq=seq)

#    __ _ _        _       
#   / _(_) |      (_)      
#  | |_ _| | ___   _  ___  
#  |  _| | |/ _ \ | |/ _ \ 
#  | | | | |  __/ | | (_) |
#  |_| |_|_|\___| |_|\___/ 

	def loadFile(name: str):
		"""
		A utility function to load a JSON file if it exists

		### Arguments
		`name: str` - The path to the file to be loaded

		`Returns: dict` - The json object if the file exists, otherwise an empty dictionary
		"""
		if (exists(f"{Server.dataPath}{name}.json")):
			with open(f"{Server.dataPath}{name}.json", "r") as data:
				return load(data)
		return {}

	def loadClients(this, file: str) -> "dict[str, Client]":
		"""
		Load the file containing the client data (if there is one) and parse it, creating a client
		object for each client.

		### Arguments
		`file: str` - The path to the file containing the client data.
		
		`Returns: dict` - The dictionary of client object for all the clients who have signed up.
		"""
		clients = Server.loadFile(file)
		result = {}
		for k,v in clients.items():
			result[k] = Client(this, username=v["username"], messages=v["messages"])
		return result

	def close(this):
		"""
		Function that needs to be run when server is closed to save data

		`Returns: void`
		"""
		this.listening = False
		this.socket.close()

		with open(f"{Server.dataPath}usernames.json", "w") as f:
			f.write(dumps(this.usernames, indent="\t"))
		clients = {}
		for name, client in this.clients.items():
			client.offline()
			clients[name] = client.data()
		with open(f"{Server.dataPath}clients.json", "w") as f:
			f.write(dumps(clients, indent="\t"))