"""
Did not have time to implement groups so this class is unused
---
"""

from time import time

class Group:
	MAX_MEMBERS = 5
	def __init__(this, server, creator: str, name: str):
		this.server = server
		this.members = {creator}
		this.name = name
		this.id = str(hash(f"{name}{time()}"))
	
	def join(this, user: str):
		if len(this.members) <= Group.MAX_MEMBERS:
			this.members.add(user)
			return True
		else:
			return False
	
	def leave(this, user: str):
		this.members.remove(user)
		if len(this.members) == 0:
			this.server.groups.pop(this.id)
