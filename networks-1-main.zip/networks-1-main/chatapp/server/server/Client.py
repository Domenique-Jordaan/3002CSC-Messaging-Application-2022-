
from socket import socket
from time import time
from typing import Any, Tuple

from .Group import Group

from ...utils.datagram import DATA, Request


class Client:
	"""
	Server Client
	---
	Not to be confused with the client class in the client side code, this class is the server's
	representation of a client and their associated methods and data.
	
	kwargs are:
	`username: str` - The Username of the client the instance represents
	`messages: list`
	`online: bool`
	`addr: (str, int)`
	`sendAddr: (str, int)`
	"""
	# This is the number of seconds after which if the server hasn't had any RESPONSES from a user they will be marked as offline
	timeout_threshold = 10
	def __init__(this, server, **kwargs: "dict[str, Any]"):
		this.server = server
		this.username: str = kwargs.get("username")
		this.messages: list[Tuple[int, str, str, int]] = kwargs.get("messages", [])
		this._online: bool = kwargs.get("online", False)
		this.lastSeen: float = time()
		this.addr: str = kwargs.get("addr")
		this._sendAddr: Tuple[str, int] = None
		this.sendAddr = kwargs.get("sendAddr")
		this.seq: int = 0
		this.currentSeq: int = this.seq
		if this._online:
			this.server.requestAddrs[this.addr] = this.username.lower()
			this.server.responseAddrs[f"{this.sendAddr[0]}:{this.sendAddr[1]}"] = this.username.lower()
			for msg in this.messages:
				this.enqueue(*msg)
			this.messages = []
		# Storing in a seq number keyed dict instead of array as this prevents msgs being popped of if dupicate responses come through
		this.queue: dict[int, Request] = {}
		this.groups: set[Group] = set()
	
	@property
	def sendAddr(this):
		"""
		Getter for the sendAddr property

		`Returns: (str, int)`
		"""
		return this._sendAddr

	@sendAddr.setter
	def sendAddr(this, val: "list[str, int]"):
		"""
		Setter for the sendAddr property.
		The json module interprets tuples as lists, ∵ JSON doesn't have the concept of a tuple.
		This getter/setter converts it back into a tuple when the value is set.

		### Arguments
		`val: [str, int]` - The sendAddr as a list

		`Returns: void`
		"""
		if val:
			this._sendAddr = (val[0], val[1])
	
	def enqueue(this, type: int, sender: str, body: str, sent: int, recipient: str=None):
		"""
		Queue a message to be sent to this client. If they are online and have an empty queue send
		them the message. If they are offline store the message. If they are online but have values
		in the queue and they have not responded in more than the timeout threshold mark them as
		offline.

		### Arguments
		`type: int` - The type of message, either MSG, RECEIVED or READ
		`sender: str` - The user sending the message
		`body: str` - The message content
		`sent: int` - When the message was sent initially by the sender
		`recipient?: str` - Would have been used with groups, not currently used.

		`Returns: void`
		"""
		req = Request("DATA", typ=type, sent=sent, sender=sender, seq=this.seq ,body=body, recipient=recipient)
		if this._online and not (len(this.queue) > 0 and (time() - this.lastSeen) > Client.timeout_threshold):
			this.queue[this.seq] = req
			this.seq += 1
			if (len(this.queue) == 1):
				this.server.socket.sendto(req.encode(), this.sendAddr)
				this.currentSeq = req.header["seq"]
			return
		else:
			# if there is a recipient it means its a group message and doesn't need to be stored
			if not recipient:
				this.queue[this.seq] = req	
			this.offline()
		
	def dequeue(this, seq: int):
		"""
		Remove a message from the queue, refresh the user's last seen time, and send the next
		message in the queue if there is one.

		### Arguments
		`seq: int` - The sequence number to dequeue
		"""
		this.seen()
		if seq in this.queue:
			# Now that a response has been received for a message the next message can be sent, if there is one
			result = this.queue.pop(seq)
			if len(this.queue) > 0:
				this.server.socket.sendto(this.queue[seq + 1].encode(), this.sendAddr)
				this.currentSeq = seq + 1
			return result
	
	def resend(this):
		"""
		Resend is called when the server receives a response that is either corrupt or not OK

		`Returns: void` 
		"""
		this.seen()
		this.server.socket.sendto(this.queue[this.currentSeq].encode(), this.sendAddr)
	
	def online(this, addr: Tuple[str, int], sendAddr: "list[str, int]"):
		"""
		Set this client as online and begin forwarding them their messages that arrived while they
		were offline.

		### Arguments
		`addr - (str, int)` - Their recieving address for Responses
		`sendAddr - [str, int]` - Their recieving address for Requests

		`Returns: void`
		"""
		this._online = True
		this.addr = addr
		this.sendAddr = sendAddr
		this.seq = 0
		this.seen()
		this.server.requestAddrs[this.addr] = this.username.lower()
		this.server.responseAddrs[f"{this.sendAddr[0]}:{this.sendAddr[1]}"] = this.username.lower()
		print(this.username, "logged in")
		# Start sending user their messages
		for msg in this.messages:
			this.enqueue(*msg)
		this.messages = []

	def offline(this):
		"""
		Mark a user as offline and remove their addresses from the server lookup tables.

		`Returns: void`
		"""
		if this._online:
			this._online = False
			this.seq = 0
			this.currentSeq = this.seq
			for group in this.groups:
				group.leave(this.username.lower())
			this.groups = set()
			this.server.requestAddrs.pop(this.addr)
			this.server.responseAddrs.pop(f"{this.sendAddr[0]}:{this.sendAddr[1]}")
			print(this.username, "logged out")
		for _, req in sorted(list(this.queue.items()), key=lambda v: v[0]):
			this.messages.append((req.header["type"], req.header["sender"], req.body, req.header["sent"]))
		this.queue = {}

	def data(this):
		"""
		`Returns: {"username": str, "messages": list[(str, str, int, int)]}` - An object containing
		the client's messages and username. This method is used to get the client data to write to a
		file.
		"""
		return {"username": this.username, "messages": this.messages}
	
	def seen(this):
		"""
		Update the time a packet was last received from this client.

		`Returns: void`
		"""
		this.lastSeen = time()