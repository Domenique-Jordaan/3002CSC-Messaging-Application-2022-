from sys import argv
import threading
from .server.Server import Server


port = int(argv[1]) if len(argv) > 1 else 42069

server = Server(port)
t = threading.Thread(target=server.start)
t.start()

input("Press enter to close\n")
server.close()
t.join()