import socket as soc
import threading
from time import time
from typing import Callable
from ...utils.datagram import AUTH, CTRL, DATA, STATUS, Request, Response, decode

class Connection:
	"""
	A Class representing a connection to the server
	-----------------------------------------------
	The connection class represents a client's connection to the server. It is an abstraction of the
	communication with the server, centralizing all of the error checking and loss prevention.

	### Arguments
	`host: str` - The ip address or domain name of the server.
	`port: int` - The port to send to on the server.
	`callback: function(Request)` - The callback function to run when a Request is received from the
	server.
	`timeout?: float` - The number of seconds to wait for a response on the socket before timing
	out. `Default: 1.0`.
	`resubmit?: int` - The number of times to attempt to resubmit the msg if something goes wrong.
	`Default: 3`.
	`clientPort?: int` - The port to listen on. `Default: port + 1`. Needs to be set if running
	multiple clients on the same device.
	"""
	def __init__(this, host: str, port: int, callback: Callable[[Request], None], timeout: float=1.0, resubmit: int=3, clientPort:int=None):
		this.host = host
		this.port = port
		this.callback = callback
		this.seq = 0
		this.listening = False
		this.attempts = resubmit	# How many resubmit attempts to make
		this.sender = soc.socket(soc.AF_INET, soc.SOCK_DGRAM)
		this.timeout = timeout
		this.sender.settimeout(timeout)
		this.receiver = soc.socket(soc.AF_INET, soc.SOCK_DGRAM)
		if clientPort: print("clientPort is", clientPort)
		this.addr = (soc.gethostbyname(soc.gethostname()), clientPort if clientPort else port+1)
		this.receiver.bind(this.addr)
		this.listener = threading.Thread(target=this.listen, daemon=True).start()
		this.lock = threading.Lock()

	def listen(this):
		"""
		Listen to incoming messages from the server.

		This method is blocking and should be called on a new thread.
		`Returns: void`
		"""
		this.listening = True
		try:
			while this.listening:
				msg, addr = this.receiver.recvfrom(2048)
				threading.Thread(target=this.handleRequest, args=(decode(msg), addr)).start()
		except OSError: pass
	
	def handleRequest(this, req: Request, addr: str):
		"""
		Handle incoming Request objects from the server. by calling the callback and sending an OK
		response or, if they are corrupt, a bad request	response.

		`Returns: void`
		"""
		if req.corrupt:
			print("msg corrupt")
			res = Response(STATUS.BAD_REQUEST, seq=req.header["seq"])
		else:
			res = Response(STATUS.OK, seq=req.header["seq"], body=req.header["sent"])
			this.callback(req)
		this.receiver.sendto(res.encode(), addr)

	def ping(this):
		"""
		Ping the server and print the round trip time if the ping comes back.

		`Returns: bool` - Whether the server responded
		"""
		start = time()
		res: Response = this.makeRequest("p", this.lock)
		if res.status == STATUS.TIME_OUT:
			print("server silent")
		elif res.status == STATUS.OFFLINE:
			print("server offline")
		else:
			print("round trip time:", (time() - start)*1000, "ms")
			return True
		return False

	def signUp(this, username: str) -> Response:
		"""
		Contact server, telling it you are a new user, and ask it for a unique tag for your username.
		Return the response.

		### Arguments
		`username: str` - The username you would like to sign up with.

		`Returns: Response` - The response object from the server
		"""
		this.seq = 0
		res = this.makeRequest(Request("AUTH", typ=AUTH.SIGNUP, seq=this.seq, sender=username, body=this.addr), this.lock)
		return res

	def logIn(this, username: str) -> Response:
		"""
		Let the server know that you are coming online so it can send you all of your messages, and
		so other clients can contact you.

		### Arguments
		`username: str` - Your username

		`Returns: Response` - The response object from the server
		"""
		this.seq = 0
		res = this.makeRequest(Request("AUTH", typ=AUTH.LOGIN, seq=this.seq, sender=username.lower(), body=this.addr), this.lock)
		return res

	def startChat(this, recipient: str) -> Response:
		"""
		Contact the server to see if a given user has ever signed up, and if they have get their
		case specific username.

		### Arguments
		`recipient: str` - The username of the person you want to start a chat with

		`Returns: Response` - The response object from the server
		"""
		res = this.makeRequest(Request("CTRL", typ=CTRL.START_CHAT, seq=this.seq, body=recipient.lower()), this.lock)
		return res

	#! Didn't have time to implement groups
	# def startGroup(this, name: str):
	# 	res = this.makeRequest(Request("CTRL", typ=CTRL.START_GROUP, seq=this.seq, body=name), this.lock)
	# 	return res

	# def joinGroup(this, id: str):
	# 	res = this.makeRequest(Request("CTRL", typ=CTRL.JOIN_GROUP, seq=this.seq, body=id), this.lock)
	# 	return res

	# def leaveGroup(this, id: str):
	# 	res = this.makeRequest(Request("CTRL", typ=CTRL.LEAVE_GROUP, seq=this.seq, body=id), this.lock)
	# 	return res

	def logOut(this):
		"""
		Let the server know that you will no longer recieving messages so it can mark you as offline
		and store your messages instead of forwarding them to you.
		`Returns: void`
		"""
		this.makeRequest(Request("CTRL", typ=CTRL.LOGOUT), this.lock)
		this.listening = False
		this.receiver.close()
	
	def sendMsg(this, recipient: str, msg: str, time: int) -> Response:
		"""
		Send a text message to another user via the server.

		### Arguments
		`recipient: str` - The username of the person you want to message
		`msg: str` - The text you want to send them
		`time: int` - The time you sent the message

		`Returns: Response` - The response object from the server
		"""
		res = this.makeRequest(Request("DATA", typ=DATA.MSG, recipient=recipient.lower(), body=msg, sent=time), this.lock)
		return res
	
	def msgRead(this, recipient: str, sent: int):
		"""
		Send a message to the server telling it you have read the messages for a given chat, so it
		can inform the sender.
		### Arguments
		`recipient: str` - The user who's messages you have read
		`sent: int` - The timestamp of the last message from the recipient in the chat you read

		`Returns: void`
		"""
		this.makeRequest(Request("DATA", typ=DATA.READ, recipient=recipient.lower(), sent=sent), this.lock)

	def makeRequest(this, req: Request, lock: threading.Lock):
		"""
		Send a Request packet to the server, and handle all the possible responses. Some handling
		paths have not been completed because I didn't have time.

		### Arguments
		`req: Request | str` - The request object to send to the server, or a single character if it
		is a ping.
		`lock: threading.lock` - The threading lock. This method is called by methods which are
		called asynchrenously, therefore in order to only send one message at a time a threading
		lock is required.

		`Returns: Response` - The response object from the server, or an offline/timeout response if
		the server is offline
		"""
		lock.acquire()
		res = None
		resend = True
		if type(req) != str:
			this.seq += 1
		reqBytes = req.encode()
		for i in range(this.attempts):
			try:
				if resend:
					this.sender.sendto(reqBytes, (this.host, this.port))
				if type(req) == str or req.header["type"] != CTRL.LOGOUT:
					msg, addr = this.sender.recvfrom(2048)
				elif req.header["type"] == CTRL.LOGOUT:
					lock.release()
					return
				res: Response = decode(msg)
				# If the type is str its a ping ∴ checks are irrelevant as any response is a valid response
				if type(req) == str or res.status == STATUS.OK:
					break
				elif res.corrupt or res.status == STATUS.BAD_REQUEST:
					print("REQ or RES CORRUPT")
					continue
				# If seq number is behind it must be a response for a previous message that got duplicated. Dismiss it and listen again  
				elif res.header["seq"] != req.header["seq"]:
					# set the timeout very short and then check port again to see if desired message was "behind" duplicated message
					this.sender.settimeout(0.01)
					resend = not resend
					print("OUT OF SYNC")
				elif res.status == STATUS.NO_AUTH and req.header["type"] != CTRL.LOGOUT:
					#todo implement re log in
					print("NOT AUTHENTICATED")
				break
			except soc.timeout:
				this.sender.settimeout(this.timeout)
				res = Response(STATUS.TIME_OUT)
			except:
				res = Response(STATUS.OFFLINE)
		this.sender.settimeout(this.timeout)
		lock.release()
		return res