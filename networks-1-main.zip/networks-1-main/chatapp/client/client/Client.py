import os
import threading
from typing import Tuple
import eel
from os import remove
from os.path import exists
from json import load, dumps
from sys import platform

from ...utils.datagram import DATA, MSG, STATUS, Request

from .Connection import Connection

class Client:
	"""
	A Class representing the client application
	-------------------------------------------
	The client class represents the client application running on the user's computer. It performs
	file io, interacts with the GUI and communicates with the server using a Connection class.

	### Arguments
	`host: str` - The ip address or domain name of the server.
	`port: int` - The port to send to on the server.
	`clientPort?: int` - The port to listen on. If not specified it defaults to the server port +1.
	If specified the info for that client instance will be saved in a folder with the port number as
	the name. This prevents new instances of the app on the same computer reading the same userdata
	as the running instance.
	"""
	dataPath = "./chatapp/client/data/"

	def __init__(this, host: str, port: int, clientPort: int = None):
		if clientPort:
			path = f"{Client.dataPath}{clientPort}"
			if not os.path.isdir(path):
				os.mkdir(path)
				print(f"added new data instance in {path}")
			else:
				print(f"using alternate client data from {path}")
			Client.dataPath = path + "/"

		this.host = host
		this.port = port
		this.username = None
		this.contacts: dict[str, dict[str, list[Tuple[str, str, int, int]]]] = {}
		for fileName in os.listdir(Client.dataPath):
			if (fileName.endswith(".json") and "#" in fileName):
				name = fileName[0:-5]
				with open(f"{Client.dataPath}{fileName}", "r") as f:
					this.contacts[name] = load(f)
		this.openChat: str = ""
		this.exposeMethods()
		this.server = Connection(this.host, this.port, this.callback, clientPort=clientPort)

	def callback(this, req: Request):
		"""
		This is the function that is passed to the connection object to be called when a Request
		comes in from the server

		### Arguments
		`req: Request` - A Request object from the server.

		`Returns: void`
		"""
		if req.header["type"] == DATA.MSG:
			msg = (req.body, req.header["sender"], req.header["sent"], MSG.READ)
			if req.header["sender"] not in this.contacts:
				this.contacts[req.header["sender"]] = {"messages": [], "unread": 0}
			this.contacts[req.header["sender"]]["messages"].append(msg)
			if this.openChat == req.header["sender"]:
				this.server.msgRead(this.openChat, req.header["sent"])
			else:
				this.contacts[req.header["sender"]]["unread"] += 1
			eel.updateUI(DATA.MSG, req.header["sender"], msg)

		elif req.header["sender"] in this.contacts:
			if req.header["type"] == DATA.RECEIVED:
				for m in reversed(this.contacts[req.header["sender"]]["messages"]):
					if (m[1] == this.username and m[2] == req.body):
						if m[3] < MSG.RECEIVED: m[3] = MSG.RECEIVED
						break
				eel.updateUI(DATA.RECEIVED, req.header["sender"], req.body)
			elif req.header["type"] == DATA.READ:
				mark = False
				for m in reversed(this.contacts[req.header["sender"]]["messages"]):
					if (m[1] == this.username and m[2] == req.body): mark = True
					if mark:
						if m[3] == MSG.RECEIVED or m[3] == MSG.SENT: m[3] = MSG.READ
						elif m[3] == MSG.READ: break
				eel.updateUI(DATA.READ, req.header["sender"], req.body)

	def start(this):
		"""
		Start client GUI

		`Returns: void`
		"""
		print("starting client")
		threading.Thread(target=this.server.listen, daemon=True)
		eel.init("./chatapp/client/interface/public")
		mode = "chrome" if platform == "win32" else "chrome-app"
		eel.start("index.html", mode=mode , host='localhost', port=0, block=True, disable_cache=True, close_callback=this.onClose, cmdline_args=["--start-fullscreen"])

	def signUp(this, username: str):
		"""
		Contact server, telling it you are a new user, and ask it for a unique tag for your username.
		Write username and tag to "database"

		### Arguments
		`username: str` - The username you would like to sign up with.

		`Returns: int` - The tag received from the server
		"""
		res = this.server.signUp(username)
		this.saveData({"username": username, "tag": res.body})
		this.username == f"{username}#{res.body:0>4}"
		return int(res.body)
	
	def makeContact(this, login: bool=False):
		"""
		Attempt to contact the server, and if successful set GUI online flag to true, else false.

		### Arguments
		`login?: bool` - Whether to log in. If not the server is pinged to determine if it is online

		`Returns: void`
		"""
		if login:
			res = this.server.logIn(this.username)
			eel.setOnline(res.status == STATUS.OK)
		else:
			eel.setOnline(this.server.ping())

	def startChat(this, name: str):
		"""
		Contact server and ask if the given user has signed up. If they have create a new contact
		for them if you don't have one already.

		### Arguments
		`name: str` - The username of the person you want to start a chat with

		`Returns: str` - The case correct username of the person you want to start talking to, or a
		blank string if they don't exist.
		"""
		res = this.server.startChat(name)
		if res.status == STATUS.OK:
			if res.body not in this.contacts:
				this.contacts[res.body] = {"messages": [], "unread": 0}
			return res.body
		else: return ""

	def sendMessage(this, msg: Tuple[str, str, int, int]):
		"""
		Send a text message to another user via the server, and mark the message as sent when a
		response from the server is received.

		### Arguments
		`msg: (str, str, int, int)` - The message object. Messages are tuples containing the message
		body, the username of the sender, the time sent and the read status.

		`Returns: int` - The timestamp of the message to  be marked as sent, or 0 if the
		message didn't go through.
		"""
		this.contacts[this.openChat]["messages"].append(msg)
		res = this.server.sendMsg(this.openChat, msg[0], msg[2])
		if (res.status == STATUS.OK):
			# mark the message with the corresponding time stamp
			for m in reversed(this.contacts[this.openChat]["messages"]):
				if (m[2] == res.body and m[1] == this.username):
					if (m[3] < MSG.SENT): m[3] = MSG.SENT
					break
			return res.body
		return 0

	def getMessages(this, contact: str):
		"""
		Return the messages for a specific contact and contact the server if there were unread
		messages from this contact letting it know those messages are read. No validation needs to
		be performed on the contact as that is done in the UI code.

		### Arguments
		`contact: str` - The contact you want to receive the messages for.

		`Returns: list[Tuple[str, str, int, int]]` - The array of message tuples for the given user
		"""
		this.openChat = contact
		if (this.contacts[this.openChat]["unread"] > 0):
			this.server.msgRead(this.openChat, this.contacts[this.openChat]["messages"][-1][2])
		this.contacts[this.openChat]["unread"] = 0
		return this.contacts[this.openChat]["messages"]

#    __ _ _        _       
#   / _(_) |      (_)      
#  | |_ _| | ___   _  ___  
#  |  _| | |/ _ \ | |/ _ \ 
#  | | | | |  __/ | | (_) |
#  |_| |_|_|\___| |_|\___/ 

	def deleteChat(this):
		"""
		Delete the file associated with the active chat and remove its entry in memory

		`Returns: void`
		"""
		if exists(f"{Client.dataPath}/{this.openChat}.json"):
			remove(f"{Client.dataPath}/{this.openChat}.json")
		this.contacts.pop(this.openChat)
		this.openChat = ""
	
	def saveData(this, data: "dict[str, int | str]"):
		"""
		Save the user's details.
		"""
		with open(f"{Client.dataPath}data.json", "w") as f:
			f.write(dumps(data, indent="\t"))

	def loadData(this):
		"""
		Load messages from contacts from disk, assign object to contacts and return a summary

		`Returns: dict[str, {"messages"?: (str, str, int, int), "unread": int}]` - A summary of the
		user's contacts which the UI code will use to construct the menu.
		"""
		for fileName in os.listdir(Client.dataPath):
			if (fileName.endswith(".json") and "#" in fileName):
				name = fileName[0:-5]
				with open(f"{Client.dataPath}{fileName}", "r") as f:
					this.contacts[name] = load(f)
		# create cache to send to js
		cache = {}
		for k, v in this.contacts.items():
			cache[k] = {"message": v["messages"][-1] if len(v["messages"]) > 0 else None, "unread": v["unread"]}
		return cache

	def authenticate(this):
		"""
		Load the user's details from disk if they exist, and use them to connect to the server.

		`Returns: {"username": str, "tag": int}` - The user details for the user if they exist,
		otherwise the same dictionary with a blank string where the username would be.
		"""
		data = {"username": "", "tag": 0}
		if exists(f"{Client.dataPath}data.json"):
			with open(f"{Client.dataPath}data.json", "r") as f:
				data = load(f)
			this.username = f"{data['username']}#{data['tag']:0>4}"
			this.makeContact(this.username)
		else:
			this.makeContact()
		return data

	def onClose(this, route: str, websockets: "list[str]"):
		"""
		A cleanup function that runs when the application is closed, saving data and letting the
		server know you are going offline. The arguments are the ones passed in automatically by eel

		### Arguments
		`route: str`
		`websockets: list[str]`

		`Returns: void`
		"""
		if not websockets:
			this.server.logOut()
			for contact, data in this.contacts.items():
				with open(f"{Client.dataPath}/{contact}.json", "w") as f:
					f.write(dumps(data, indent="\t"))
			exit()

	def exposeMethods(this):
		"""
		A function to expose the messages of this class to the GUI code so that it can use them

		`Returns: void`
		"""
		eel.expose(this.loadData)
		eel.expose(this.authenticate)
		eel.expose(this.signUp)
		eel.expose(this.makeContact)
		eel.expose(this.startChat)
		eel.expose(this.getMessages)
		eel.expose(this.sendMessage)
		eel.expose(this.deleteChat)
