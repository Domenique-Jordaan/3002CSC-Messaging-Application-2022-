<script lang="ts">
	import { afterUpdate, onDestroy, onMount } from "svelte";
	import Bubble from "./Bubble.svelte";
	import { messages } from "./stores";

	import { global, MSG } from "./utils";

	export function markSent(stamp: number) {
		for (let i = $messages.length - 1; i >= 0; --i) {
			if ($messages[i][1] === global.username) {
				if ($messages[i][2] === stamp && $messages[i][3] === 0) {
					$messages[i][3] = 1;
				} else break;
			}
		}
	}

	let scroll = false;
	let div: HTMLDivElement;

	afterUpdate(() => {
		div.scrollTo(0, div.scrollHeight);
		scroll = true;
	});
</script>

<div class:scroll class="messages" bind:this={div}>
	{#each $messages as msg}
		<Bubble message={msg} />
	{/each}
</div>

<style lang="scss">
	.messages {
		flex-grow: 1;
		padding: 2rem 4rem;
		display: flex;
		flex-direction: column;
		overflow-y: auto;
		&.scroll {
			scroll-behavior: smooth;
		}
	}
</style>
