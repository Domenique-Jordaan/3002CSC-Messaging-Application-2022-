<script lang="ts">
	import Modal from "./Modal.svelte";
	import Menu from "./Menu.svelte";
	import Chat from "./Chat.svelte";
	import Signup from "./Signup.svelte";
	import NameInput from "./NameInput.svelte";
	import Input from "./Input.svelte";
	import { DATA, formatTag, global, MSG } from "./utils";
	import { messages, openChat, update } from "./stores";
	import { onDestroy } from "svelte";

	export let details: UserDetails;
	export let contacts: Contacts;

	if (details?.username) global.username = formatTag(details.username, details.tag);

	let newChat = false;
	let newGroup = 0;

	function signUp(e: CustomEvent) {
		details = { ...e.detail };
		global.username = formatTag(details.username, details.tag);
	}

	function addContact(e: CustomEvent) {
		newChat = false;
		if (!contacts[e.detail.username]) {
			contacts[e.detail.username] = { message: null, unread: 0 };
		}
		$openChat = e.detail.username;
	}

	function findGroup(e: CustomEvent) {}

	function createGroup(e: CustomEvent) {}

	function handleKeystroke(e: KeyboardEvent) {
		if (e.key === "Escape") {
			newChat = false;
			newGroup = 0;
		}
	}

	const unsub = update.subscribe((e) => {
		if (!e) return;
		switch (e.type) {
			case DATA.MSG: {
				if (contacts[e.sender]) {
					contacts[e.sender].message[0] = e.data[0];
				} else {
					contacts[e.sender] = { message: e.data, unread: 0 };
				}
				if (e.sender === $openChat) {
					messages.update((old) => {
						old.push(e.data);
						return old;
					});
				} else contacts[e.sender].unread += 1;
				break;
			}
			case DATA.RECEIVED: {
				if (e.sender === $openChat) {
					for (let i = $messages.length - 1; i >= 0; --i) {
						if ($messages[i][1] == global.username && $messages[i][2] == e.data) {
							if ($messages[i][3] < MSG.RECEIVED) {
								$messages[i][3] = MSG.RECEIVED;
							}
							break;
						}
					}
				}
				break;
			}
			case DATA.READ: {
				let mark = false;
				for (let i = $messages.length - 1; i >= 0; --i) {
					if ($messages[i][1] == global.username && $messages[i][2] == e.data)
						mark = true;
					if (mark) {
						if ($messages[i][3] === MSG.RECEIVED || $messages[i][3] === MSG.SENT) {
							$messages[i][3] = MSG.READ;
						} else if ($messages[i][3] === MSG.READ) break;
					}
				}
				break;
			}
		}
	});

	onDestroy(unsub);
</script>

<svelte:body on:keydown={handleKeystroke} />

{#if details?.username}
	<div class="app">
		<Menu
			{contacts}
			{details}
			on:newChat={() => (newChat = true)}
			on:newGroup={() => (newGroup = 1)}
		/>
		<Chat bind:contacts />
	</div>
{:else}
	<Signup on:signUp={signUp} />
{/if}

{#if newChat}
	<Modal on:close={() => (newChat = false)}>
		<div class="add-friend desc">
			<h1>Add chat</h1>
			<div>Add a friend using their username and tag</div>
		</div>
		<NameInput on:submit={addContact} />
	</Modal>
{/if}

{#if newGroup}
	<Modal on:close={() => (newGroup = 0)}>
		{#if newGroup === 1}
			<div class="group-options">
				<button class="btn" on:click={() => (newGroup = 2)}>new group</button>
				<button class="btn" on:click={() => (newGroup = 3)}>join group</button>
			</div>
		{:else if newGroup === 2}
			<div class="new-group desc">
				<h1>create new group</h1>
				<div>Name your new group</div>
				<Input
					valid={/^.{3,20}$/m}
					maxlength={20}
					button="create"
					on:submit={createGroup}
				/>
			</div>
		{:else if newGroup === 3}
			<div class="join-group desc">
				<h1>join group</h1>
				<div>Enter the ID of the group you want to join</div>
				<Input
					keyRule={/\d/m}
					valid={/^\d{15}$/m}
					maxlength={15}
					button="find"
					on:submit={findGroup}
				/>
			</div>
		{/if}
	</Modal>
{/if}

<style lang="scss">
	.app {
		display: grid;
		grid-template-columns: 35rem 1fr;
		height: 100%;
	}
	.desc {
		display: flex;
		flex-direction: column;
		align-items: center;
		text-align: center;
		font-size: 2rem;
		div {
			font-size: 1.8rem;
			color: var(--fg-secondary);
		}
	}
	.group-options {
		display: grid;
		grid-template-columns: 1fr 1fr;
		gap: 2rem;
		height: 8rem;
	}
</style>
