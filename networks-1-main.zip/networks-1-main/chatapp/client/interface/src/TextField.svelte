<script lang="ts">
	import { createEventDispatcher, onMount } from "svelte";
	import { global } from "./utils";

	const dispatch = createEventDispatcher();
	let text = "";
	let edit: HTMLDivElement;

	function send() {
		if (!/^\s*$/m.test(text)) {
			dispatch("send", { message: [text, global.username, new Date().valueOf(), 0] });
			text = "";
		}
	}

	function processKey(e: KeyboardEvent) {
		if (e.key === "Enter" && !e.shiftKey) {
			e.preventDefault();
			send();
		}
		if (!text && (e.key === "Enter" || e.key === " ")) {
			e.preventDefault();
		}
	}
	onMount(() => edit.focus());
</script>

<div class="bar">
	<div class="input">
		{#if !text}
			<div class="placeholder">Type a message</div>
		{/if}
		<div
			class="edit"
			bind:this={edit}
			contenteditable="true"
			bind:textContent={text}
			on:keypress={processKey}
		/>
	</div>
	<div class="send" on:click={send}>
		<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">
			<path
				d="M.451 55.544c-.2 1.531 1.338 2.702 2.761 2.101l56.421-23.804c1.63-.688 1.63-2.998 0-3.686L3.211 6.355c-1.423-.6-2.96.57-2.761 2.101L3 28l34 4-34 4L.451 55.544z"
			/>
		</svg>
	</div>
</div>

<style lang="scss">
	.bar {
		max-height: 35rem;
		height: 7rem;
		padding: 1rem;
		background: var(--bg-alt);
		display: flex;
		align-items: center;
		gap: 1rem;
		.input {
			border-radius: 3rem;
			background: var(--bg-primary);
			flex-grow: 1;
			position: relative;
		}
		.edit {
			outline: none;
			padding: 1.5rem;
			white-space: pre-wrap;
		}
		.placeholder {
			padding: 1.5rem;
			position: absolute;
			inset: 0;
			color: var(--fg-secondary);
			pointer-events: none;
		}
	}
	.send {
		height: 5rem;
		aspect-ratio: 1;
		border-radius: 50%;
		padding: 1rem;
		cursor: pointer;
		transition: all 0.1s ease;
		&:hover {
			background: var(--primary);
		}
		&:active {
			transform: scale(0.9);
		}
		svg {
			transform: translateX(0.3rem);
			fill: white;
		}
	}
</style>
