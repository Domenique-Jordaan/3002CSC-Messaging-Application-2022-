<script lang="ts">
	import Contact from "./Contact.svelte";
	import Offline from "./Offline.svelte";
	import { createEventDispatcher } from "svelte";
	import { formatTag } from "./utils";
	import { online, ONLINE } from "./stores";

	export let details: UserDetails;
	export let contacts: Contacts;

	const dispatch = createEventDispatcher();

	function copyUsername() {
		navigator.clipboard.writeText(formatTag(details.username, details.tag));
	}
</script>

<aside>
	<div class="options">
		<div class="handle" title="copy username" on:click={copyUsername}>
			<div class="username">{details.username}</div>
			<div class="tag">#{`${details.tag}`.padStart(4, "0")}</div>
		</div>
		<div class="buttons">
			<svg
				class:enabled={$online === ONLINE.TRUE}
				xmlns="http://www.w3.org/2000/svg"
				viewBox="0 0 64 64"
				fill-rule="evenodd"
				on:click={() => $online === ONLINE.TRUE && dispatch("newChat")}
				><path
					d="M32.451 18.566c1.278 0 2.313 1.036 2.313 2.313v4.279h4.279c1.278 0 2.313 1.036 2.313 2.313s-1.036 2.313-2.313 2.313h-4.279v4.279c0 1.278-1.036 2.313-2.313 2.313s-2.313-1.036-2.313-2.313v-4.279h-4.279c-1.277 0-2.313-1.036-2.313-2.313s1.036-2.313 2.313-2.313h4.279V20.88c0-1.278 1.036-2.313 2.313-2.313zM11.169 7A6.17 6.17 0 0 0 5 13.169v41.354a2.47 2.47 0 0 0 3.815 2.067l12.527-8.164c.251-.163.543-.25.842-.25h31.394a6.17 6.17 0 0 0 6.169-6.169V13.169A6.17 6.17 0 0 0 53.578 7h-42.41zm0 4.627c-.852 0-1.542.691-1.542 1.542v37.37l9.189-5.989a6.17 6.17 0 0 1 3.368-1.001h31.394c.852 0 1.542-.691 1.542-1.542V13.169c0-.852-.691-1.542-1.542-1.542h-42.41z"
				/><path
					d="M34.764 20.88c0-1.278-1.036-2.313-2.313-2.313s-2.313 1.036-2.313 2.313v4.279h-4.279c-1.277 0-2.313 1.036-2.313 2.313s1.036 2.313 2.313 2.313h4.279v4.279c0 1.278 1.036 2.313 2.313 2.313s2.313-1.036 2.313-2.313v-4.279h4.279c1.278 0 2.313-1.036 2.313-2.313s-1.036-2.313-2.313-2.313h-4.279V20.88z"
				/>
			</svg>
			<svg
				xmlns="http://www.w3.org/2000/svg"
				viewBox="0 0 64 64"
				fill-rule="evenodd"
				on:click={() => $online === ONLINE.TRUE && dispatch("newGroup")}
				><path
					d="M58.721 20.198A5.28 5.28 0 0 1 64 25.478v33.139a2.47 2.47 0 0 1-3.841 2.05l-12.274-8.228a1.54 1.54 0 0 0-.859-.261H23.631a5.28 5.28 0 0 1-5.279-5.28v-.008l.027-3.713h-1.195c-.299 0-.591.087-.842.25L3.815 51.59A2.47 2.47 0 0 1 0 49.523V8.169A6.17 6.17 0 0 1 6.169 2h42.41a6.17 6.17 0 0 1 6.169 6.169v12.029h3.974zm0 4.627c.36 0 .653.292.653.653V54.57l-8.913-5.975a6.17 6.17 0 0 0-3.435-1.045H23.631a.65.65 0 0 1-.652-.648l.027-3.727h25.573a6.17 6.17 0 0 0 6.169-6.169V24.824h3.974zM6.169 6.627a1.54 1.54 0 0 0-1.542 1.542v37.37l9.189-5.989a6.17 6.17 0 0 1 3.368-1.001h31.394c.852 0 1.542-.691 1.542-1.542V8.169c0-.852-.691-1.542-1.542-1.542H6.169zm21.282 6.939c1.278 0 2.313 1.036 2.313 2.313v4.279h4.279c1.278 0 2.313 1.036 2.313 2.313s-1.036 2.313-2.313 2.313h-4.279v4.28c0 1.278-1.036 2.313-2.313 2.313s-2.313-1.036-2.313-2.313v-4.28h-4.279c-1.277 0-2.313-1.036-2.313-2.313s1.036-2.313 2.313-2.313h4.279V15.88c0-1.278 1.036-2.313 2.313-2.313z"
				/>
			</svg>
		</div>
	</div>
	<div class="chats">
		{#if $online === ONLINE.FALSE}
			<Offline login={true} />
		{/if}
		{#each Object.entries(contacts) as cont (cont[0])}
			<Contact contact={cont} />
		{/each}
	</div>
</aside>

<style lang="scss">
	aside {
		background: var(--bg-secondary);
		display: flex;
		flex-direction: column;
		border-right: 1px solid var(--bg-primary);
	}
	.options {
		height: 5rem;
		display: flex;
		justify-content: space-between;
		background: var(--bg-alt);
		padding: 1rem;
		user-select: none;
		cursor: copy;
	}
	.handle {
		flex-grow: 1;
	}
	.username {
		font-weight: bold;
		font-size: 1.1em;
	}
	.tag {
		color: var(--fg-secondary);
		font-size: 0.8em;
	}
	.buttons svg {
		fill: var(--fg-secondary);
		margin-left: 1rem;
		width: 32px;
		cursor: not-allowed;
		&.enabled {
			fill: var(--fg-primary);
			cursor: pointer;
			transition: transform 0.1s ease;
			&:hover {
				transform: scale(1.1);
			}
			&:active {
				transform: scale(0.9);
			}
		}
	}
</style>
