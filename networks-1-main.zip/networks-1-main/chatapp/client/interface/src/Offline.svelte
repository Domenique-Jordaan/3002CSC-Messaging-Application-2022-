<script lang="ts">
	import { online, ONLINE } from "./stores";
	import { makeContact } from "./utils";

	export let login: boolean = false;

	function reconnect() {
		$online = ONLINE.TBD;
		makeContact(login);
	}
</script>

<div class="unreachable" class:login>
	<div class="symbol">
		<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 65 48">
			<path
				class="wifi"
				d="M1.097 17.046c-1.459-1.459-1.486-3.831.062-5.195C9.529 4.475 20.517 0 32.55 0a47.31 47.31 0 0 1 30.565 11.139c1.734 1.459 1.724 4.073.121 5.675s-4.189 1.584-5.946.153C50.406 11.361 41.62 8 32.05 8c-9.688 0-18.572 3.444-25.494 9.175-1.606 1.33-3.986 1.345-5.46-.129zM32.05 13c8.444 0 16.189 2.99 22.235 7.969 1.448 1.192 1.438 3.357.112 4.684s-3.466 1.307-4.945.153A27.38 27.38 0 0 0 32.55 20c-6.481 0-12.438 2.242-17.139 5.993-1.629 1.3-4.015 1.353-5.489-.12-1.447-1.447-1.459-3.812.133-5.099A34.85 34.85 0 0 1 32.05 13zm7.348 21.92c1.975 1.112 4.558 1.174 6.16-.428s1.619-4.238-.247-5.525A22.39 22.39 0 0 0 32.55 25a22.4 22.4 0 0 0-13.671 4.628c-1.631 1.249-1.577 3.624-.125 5.076 1.485 1.485 3.878 1.433 5.687.366A14.93 14.93 0 0 1 32.05 33a14.93 14.93 0 0 1 7.348 1.92zM37.05 43a5 5 0 0 1-10 0 5 5 0 0 1 10 0z"
			/>
			<path
				class="bang"
				d="M37.05 43a5 5 0 0 1-10 0 5 5 0 0 1 10 0zM26.413 5.989A5.65 5.65 0 0 1 32.05 0a5.65 5.65 0 0 1 5.637 5.989l-1.395 23.018a4.25 4.25 0 0 1-8.484 0L26.413 5.989z"
			/>
		</svg>
	</div>
	<div>
		<h1>server unreachable</h1>
		<span>Either you or the server is not online.</span>
		<span class="reconnect" on:click={reconnect}>Reconnect</span>
	</div>
</div>

<style lang="scss">
	.unreachable {
		display: grid;
		grid-template-columns: 1fr 7fr;
		place-items: center;
		background: var(--bg-alt);
		width: 50rem;
		padding: 2rem;
		gap: 1rem;
		margin: auto;
		span {
			color: var(--fg-secondary);
		}
		&.login {
			border: 1px solid var(--yellow);
			width: 100%;
			padding: 1rem;
		}
	}
	.symbol {
		background: var(--yellow);
		aspect-ratio: 1;
		border-radius: 50%;
		padding: 1rem;
		display: grid;
		place-content: center;
		svg {
			width: 100%;
		}
	}
	.wifi {
		fill: var(--bg-secondary);
	}
	.bang {
		animation: pulse 3.5s ease infinite;
	}
	.reconnect {
		text-decoration: underline;
		cursor: pointer;
		&:hover {
			color: var(--fg-primary);
		}
	}
	@keyframes pulse {
		0%,
		15%,
		85%,
		100% {
			fill: var(--red);
			opacity: 1;
		}
		50% {
			fill: var(--bg-secondary);
			opacity: 0;
		}
	}
</style>
