type UserDetails = {
	username: string;
	tag: number;
};

type Contacts = {
	[key: string]: {
		message: Message,
		unread: number,
	},
};

type Message = [
	string,
	string,
	number,
	MSG,
];

type Update = {
	type: DATA,
	sender: string,
	data;
};

type Global = {
	username: string,
};