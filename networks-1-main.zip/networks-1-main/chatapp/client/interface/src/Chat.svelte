<script lang="ts">
	import TextField from "./TextField.svelte";

	import { deleteChat, getMessages, sendMessage } from "./utils";
	import { messages, openChat } from "./stores";
	import Messages from "./Messages.svelte";
	import { onDestroy } from "svelte";

	export let contacts: Contacts;
	let msgPromise: Promise<Message[]>;
	let Msg: Messages;

	async function send(e: CustomEvent) {
		messages.update((old) => {
			old.push(e.detail.message);
			return old;
		});
		const received = sendMessage(e.detail.message);
		contacts[$openChat].message = e.detail.message;
		let rec = await received;
		if (rec) {
			Msg.markSent(rec);
		}
	}

	function del() {
		deleteChat();
		delete contacts[$openChat];
		contacts = contacts;
		$openChat = "";
	}

	const unsub = openChat.subscribe(async (user) => {
		if (user) {
			msgPromise = getMessages(user);
			$messages = await msgPromise;
		}
	});
	onDestroy(unsub);
</script>

{#if $openChat}
	{#key $openChat}
		<div class="chat">
			<div class="header">
				<div>
					<span class="username">{$openChat.split("#")[0]}</span>
					<span class="tag">#{$openChat.split("#")[1]}</span>
				</div>
				<svg on:click={del} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">
					<path
						class="lid"
						d="M55.326 8V6a3 3 0 0 0-3-3H38.663V2a2 2 0 0 0-2-2h-11a2 2 0 0 0-2 2v1H11a3 3 0 0 0-3 3v2h47.326z"
					/>
					<path
						fill-rule="evenodd"
						d="M8 11.5h47.326L52.01 64H11.316L8 11.5zm5.326 5L16.01 59h8.1l-.895-42.5h-9.889zm14.89 0l.895 42.5h5.104l.895-42.5h-6.894zm11.895 0L39.216 59h8.1L50 16.5h-9.889z"
					/>
				</svg>
			</div>
			{#await msgPromise}
				<div class="messages" />
			{:then _}
				<Messages bind:this={Msg} />
			{/await}
			<TextField on:send={send} />
		</div>
	{/key}
{:else}
	<div class="placeholder">
		<h1>Networks Assignment 1</h1>
		<h3>Created by</h3>
		<div>DVDMIK001<br />JRDDOM002<br />MTNMIC001</div>
		<!-- <div class="gui-credit">GUI by DVDMIK001</div> -->
	</div>
{/if}

<style lang="scss">
	.placeholder {
		display: grid;
		place-content: center;
		color: var(--fg-secondary);
		text-transform: uppercase;
		text-align: center;
		user-select: none;
		& > * {
			margin: 0.5rem 0;
		}
	}
	// .gui-credit {
	// 	font-size: 0.9em;
	// 	opacity: 0.6;
	// }
	.chat {
		display: flex;
		max-height: 100vh;
		flex-direction: column;
	}
	.header {
		font-size: 1.4em;
		height: 5rem;
		flex-shrink: 0;
		background: var(--bg-alt);
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 0 2rem;
	}
	.username {
		font-weight: bold;
	}
	.tag {
		color: var(--fg-secondary);
	}
	svg {
		width: 32px;
		padding: 0.2rem;
		fill: var(--fg-primary);
		cursor: pointer;
		overflow: visible;
		&:hover {
			fill: var(--red);
			.lid {
				transform: translateY(-10px) rotate(5deg);
			}
		}
	}
	.messages {
		flex-grow: 1;
	}
</style>
