<script lang="ts">
	import { openChat } from "./stores";

	export let contact: [string, { message: Message; unread: number }];

	function setActive() {
		$openChat = contact[0];
		contact[1].unread = 0;
	}
</script>

<div class="contact" class:active={contact[0] === $openChat} on:click={setActive}>
	<div>
		<span class="name">{contact[0].split("#")[0]}</span>
		<span class="tag">#{contact[0].split("#")[1]}</span>
	</div>
	<div class="preview">
		{contact[1].message ? contact[1].message[0] : " "}
		{#if contact[1].unread > 0}
			<div class="messages">{contact[1].unread}</div>
		{/if}
	</div>
</div>

<style lang="scss">
	.contact {
		padding: 1rem 0;
		margin: 0 1rem;
		border-bottom: 1px solid var(--bg-primary);
		cursor: pointer;
		position: relative;
		& > div {
			margin: 0.5rem;
		}
		&::before {
			position: absolute;
			inset: 0 0rem 0 -10rem;
			background: var(--fg-primary);
			opacity: 0.05;
			z-index: 1;
		}
		&:hover {
			padding: 1rem;
			margin: 0;
			&::before {
				content: "";
			}
		}
	}
	.name {
		font-weight: bold;
	}
	.tag {
		color: var(--fg-secondary);
	}
	.preview {
		color: var(--fg-secondary);
		font-size: 0.9em;
		white-space: nowrap;
		position: relative;
		overflow: hidden;
		&::after {
			content: "";
			background-image: linear-gradient(
				to right,
				#0000,
				var(--bg-secondary),
				var(--bg-secondary)
			);
			width: 7rem;
			position: absolute;
			right: 0;
			height: 100%;
		}
	}
	.messages {
		position: absolute;
		right: 0;
		top: 0;
		z-index: 1;
		background: var(--primary);
		border-radius: 100vw;
		padding: 0 0.5rem;
		width: min-content;
		font-weight: bold;
		color: var(--bg-secondary);
	}
	.active {
		padding: 1rem !important;
		margin: 0 !important;
		&::before {
			content: "";
			opacity: 0.1 !important;
		}
	}
</style>
