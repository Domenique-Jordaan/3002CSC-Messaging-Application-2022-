<script context="module" lang="ts">
	let instances: HTMLDivElement[] = [];
	let unreadFlag = false;
</script>

<script lang="ts">
	import { onMount } from "svelte";
	import SentStatus from "./SentStatus.svelte";

	import { global } from "./utils";

	export let message: Message;

	const fromMe = global.username === message[1];
	let instance = 0;

	let bubble: HTMLDivElement;
	let consecutive = false;
	let unreadFlagHolder = false;
	let timeStamp = (() => {
		const time = new Date(message[2]);
		const hours = time.getHours();
		const minutes = `${time.getMinutes()}`.padStart(2, "0");
		return `${hours > 12 ? hours - 12 : hours}:${minutes} ${hours < 12 ? "a" : "p"}m`;
	})();

	onMount(() => {
		if (!fromMe && message[3] === 2 && !unreadFlag) {
			unreadFlag = true;
			unreadFlagHolder = true;
		}
		instance = instances.length;
		instances[instances.length] = bubble;
		if (instance > 0) {
			if (instances[instance - 1].classList.contains("me") === fromMe) {
				consecutive = true;
				if (!instances[instance - 1].classList.contains("consecutive")) {
					instances[instance - 1].classList.add("firstConsec");
				}
			} else {
				instances[instance - 1].classList.add("diff");
			}
		}

		return () => (instances = []);
	});
</script>

{#if unreadFlagHolder && !fromMe && message[3] === 2}
	<div class="unread">
		<div>
			{instances.length - instance} unread message{instances.length - instance > 1 ? "s" : ""}
		</div>
	</div>
{/if}
<div bind:this={bubble} class:consecutive class:me={fromMe} class="bubble">
	<span class="text">{message[0]}</span>
	<span class="data">
		{timeStamp}
		{#if fromMe}
			<SentStatus status={message[3]} />
		{/if}
	</span>
</div>

<style lang="scss">
	.bubble {
		background: var(--bg-secondary);
		max-width: max(60%, 35rem);
		padding: 0.8rem;
		border-radius: 0 0.8rem 0.8rem 0.8rem;
		margin: 0.6rem 0;
		position: relative;
		align-self: flex-start;
		// display: flex;
		&::after {
			content: "";
			position: absolute;
			width: 1rem;
			aspect-ratio: 1;
			background: var(--bg-secondary);
			clip-path: polygon(100% 100%, 0 0, 100% 0);
			top: 0;
			left: 0;
			transform: translateX(-95%);
		}
		.text {
			white-space: pre-wrap;
			overflow-wrap: break-word;
		}
	}
	.me {
		background: var(--primary);
		align-self: flex-end;
		border-radius: 0.8rem 0 0.8rem 0.8rem;
		.data {
			color: var(--bg-primary);
		}
		&::after {
			background: var(--primary);
			clip-path: polygon(0 0, 0 100%, 100% 0);
			transform: translateX(95%);
			right: 0;
			left: unset;
		}
	}
	.consecutive {
		margin: 0.1rem;
		border-radius: 0.8rem;
		&::after {
			display: none;
		}
	}
	:global(div.bubble.firstConsec) {
		margin-bottom: 0.1rem !important;
	}
	:global(div.bubble.diff) {
		margin-bottom: 0.6rem;
	}
	.unread {
		text-transform: uppercase;
		display: grid;
		place-items: center;
		background-image: linear-gradient(to left, #0000, var(--bg-alt), #0000);
		margin: 1rem 0;
		div {
			font-size: 0.8em;
			background: var(--primary);
			font-weight: bold;
			padding: 0.5rem 1rem;
			border-radius: 100vw;
		}
	}
	.data {
		color: var(--fg-secondary);
		font-size: 0.8em;
		width: 5.5rem;
		float: right;
		display: flex;
		width: max-content;
		align-items: end;
		transform: translateY(3px);
		margin-left: 1rem;
	}
</style>
