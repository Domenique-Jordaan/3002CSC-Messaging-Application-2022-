<script lang="ts">
	import { createEventDispatcher, onMount } from "svelte";

	export let button: string;
	export let placeholder = "";
	export let keyRule = /.*/m;
	export let valid: RegExp;
	export let maxlength: number;

	export let value = "";

	let input: HTMLInputElement;
	const dispatch = createEventDispatcher();

	function validate(e: KeyboardEvent) {
		if (valid.test(value) && e.key === "Enter") submit();
		else if (!keyRule.test(e.key)) {
			e.preventDefault();
		}
	}

	function submit() {
		dispatch("submit", { value });
	}

	onMount(() => {
		input.focus();
	});
</script>

<div class="in">
	<input
		type="text"
		bind:this={input}
		{placeholder}
		bind:value
		on:keypress={validate}
		{maxlength}
		style="width: {maxlength * 14}px;"
	/>
	<button class="btn" disabled={!valid.test(value)} on:click={submit}>{button}</button>
</div>

<style>
	.in {
		display: flex;
		gap: 2rem;
		height: 4rem;
		margin: 2rem 0;
	}
</style>
