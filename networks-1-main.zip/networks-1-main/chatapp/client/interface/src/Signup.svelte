<script lang="ts">
	import { createEventDispatcher, onMount } from "svelte";
	import { fade } from "svelte/transition";
	import Input from "./Input.svelte";

	import { signUp } from "./utils";

	let value: string = "";

	const dispatch = createEventDispatcher();

	async function submit() {
		dispatch("signUp", { username: value, tag: await signUp(value) });
	}
</script>

<div out:fade class="signup">
	<h1>Please Choose a Username</h1>
	<div>Note that you will not be able to change this</div>
	<Input button="go" maxlength={15} valid={/^[A-Za-z\d]{3,15}$/m} bind:value on:submit={submit} />
	<ul>
		<li class:red={!/^[A-Za-z\d]+$/m.test(value)}>Only letters and / or numbers</li>
		<li class:red={value.length < 3}>3 - 15 Characters</li>
	</ul>
</div>

<style lang="scss">
	.signup {
		display: flex;
		flex-direction: column;
		font-size: 2rem;
		align-items: center;
		justify-content: center;
		position: absolute;
		inset: 0;
		background: var(--bg-primary);
	}
	ul {
		color: var(--green);
		font-size: 1.4rem;
		margin-left: -70px;
	}
	.red {
		color: var(--red);
	}
</style>
