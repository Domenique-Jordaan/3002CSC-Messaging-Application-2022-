import Loader from "./Loader.svelte";
import { loadData, authenticate } from "./utils";

export default new Loader({
	target: document.body,
	props: {
		contactsPromise: loadData(),
	}
});
