<script lang="ts">
	import { createEventDispatcher, onMount } from "svelte";
	import { global, isUser } from "./utils";

	let value = "";
	let input: HTMLInputElement;
	let wrongName = "";
	let you = false;
	const dispatch = createEventDispatcher();
	const valid = /^[A-Za-z\d]{3,15}#\d{4}$/m;

	function validate(e: KeyboardEvent) {
		if (value.toLowerCase() === global.username.toLowerCase()) {
			you = true;
		} else you = false;
		if (!you && valid.test(value) && e.key === "Enter") {
			submit();
		}
		if (value.includes("#") && (!/\d/.test(e.key) || value.split("#")[1].length >= 4)) {
			e.preventDefault();
		} else if (
			!/^[A-Za-z\d#]$/m.test(e.key) ||
			(/^[A-Za-z]$/m.test(e.key) && value.length >= 15)
		) {
			e.preventDefault();
		}
	}

	async function submit() {
		const username: string = await isUser(value);
		if (username.length > 0) {
			dispatch("submit", { username });
		} else {
			wrongName = value;
		}
	}

	onMount(() => {
		input.focus();
	});
</script>

<div class="input">
	<span class="un-in">
		<input
			bind:this={input}
			type="text"
			placeholder="Enter a username#0001"
			maxlength="20"
			on:keypress={validate}
			bind:value
		/>
		<div class="placeholder">
			<span class="username">{value || ""}</span>
			{#if value.length > 0}
				<span class="tag">
					{value.includes("#") ? "".padEnd(4 - value.split("#")[1].length, "0") : "#0000"}
				</span>
			{/if}
		</div>
	</span>
	<button class="btn" disabled={!valid.test(value) || wrongName === value} on:click={submit}>
		add
	</button>
</div>
{#if wrongName === value && value !== ""}
	<div class="no-user">There is no user with the name {value}</div>
{:else if you}
	<div class="no-user">You are {value}</div>
{/if}

<style lang="scss">
	input {
		color: var(--bg-secondary);
		caret-color: var(--fg-primary);
		width: 26.5rem;
	}
	.un-in {
		display: inline-block;
		height: 4rem;
		position: relative;
	}
	.placeholder {
		pointer-events: none;
		font-size: 1.6rem;
		position: absolute;
		inset: 0;
		padding: 0 1.5rem;
		display: flex;
		align-items: center;
		.tag {
			color: var(--fg-secondary);
			opacity: 0.9;
		}
	}
	.input {
		padding: 2rem 0;
		display: flex;
		gap: 1rem;
	}
	.no-user {
		color: var(--red);
		font-weight: bold;
	}
</style>
