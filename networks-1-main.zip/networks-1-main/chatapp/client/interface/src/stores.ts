import { writable } from "svelte/store";

export const enum ONLINE {
	"FALSE",
	"TRUE",
	"TBD",
}

export const openChat = writable<string>();

export const online = writable<ONLINE>(ONLINE.FALSE);

export const messages = writable<Message[]>([]);

export const contacts = writable<Message[]>([]);

export const update = writable<Update>();