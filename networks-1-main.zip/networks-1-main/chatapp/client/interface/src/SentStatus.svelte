<script lang="ts">
	import type { MSG } from "./utils";

	export let status: MSG;
</script>

<svg xmlns="http://www.w3.org/2000/svg" class:read={status === 3} viewBox="0 0 64 64">
	{#if status === 0}
		<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">
			<path
				fill-rule="evenodd"
				d="M34.75 29.25v-7.5a2.75 2.75 0 1 0-5.5 0V32A2.75 2.75 0 0 0 32 34.75h7.25a2.75 2.75 0 1 0 0-5.5h-4.5zM54.5 32c0 12.426-10.074 22.5-22.5 22.5S9.5 44.426 9.5 32 19.574 9.5 32 9.5 54.5 19.574 54.5 32zM49 32c0 9.389-7.611 17-17 17s-17-7.611-17-17 7.611-17 17-17 17 7.611 17 17z"
			/>
		</svg>
	{:else}
		<path
			d="M43.032 14.381a2.8 2.8 0 0 1 .487 3.93L19.78 48.77a2.8 2.8 0 0 1-4.163.284L4.07 37.801a2.8 2.8 0 0 1 3.908-4.011l9.307 9.07 21.817-27.992a2.8 2.8 0 0 1 3.93-.487z"
		/>
	{/if}
	{#if status > 1}
		<path
			d="M59.321 14.381a2.8 2.8 0 0 1 .487 3.93L36.068 48.77a2.8 2.8 0 0 1-4.163.284l-3.654-3.561a2.8 2.8 0 0 1 3.908-4.011l1.415 1.379 21.817-27.992a2.8 2.8 0 0 1 3.93-.487z"
		/>
	{/if}
</svg>

<style>
	svg {
		fill: var(--bg-primary);
		width: 1.6rem;
		margin-left: 0.3rem;
	}
	.read {
		fill: var(--blue);
	}
</style>
