<script lang="ts">
	import { createEventDispatcher } from "svelte";
	import { fade } from "svelte/transition";

	const dispatch = createEventDispatcher();
	const close = () => dispatch("close");
</script>

<div transition:fade={{ duration: 100 }} on:click|self={close} class="overlay">
	<div class="modal">
		<div class="close" on:click={close}>×</div>
		<slot />
	</div>
</div>

<style lang="scss">
	.overlay {
		position: absolute;
		inset: 0;
		z-index: 10;
		display: grid;
		place-items: center;
		&::before {
			content: "";
			background: var(--bg-secondary);
			position: absolute;
			inset: 0;
			opacity: 0.95;
		}
	}
	.modal {
		--padding: 2rem;
		background: var(--bg-primary);
		padding: var(--padding);
		width: max(50rem, 50%);
		z-index: 10;
		display: flex;
		flex-direction: column;
		align-items: center;
		position: relative;
	}
	.close {
		position: absolute;
		font-size: 3rem;
		top: 0;
		right: 0;
		width: 3.2rem;
		height: 3.2rem;
		text-align: center;
		cursor: pointer;
	}
</style>
