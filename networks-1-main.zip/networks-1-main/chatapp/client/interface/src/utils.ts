import { online, ONLINE, update } from "./stores";

// import * as eel from "./dummyEel";
declare let eel: any;

export const enum MSG {
	UNSENT,
	SENT,
	RECEIVED,
	READ,
}

export const enum DATA {
	MSG,
	RECEIVED,
	READ,
}

export async function signUp(username: string) {
	return await eel.signUp(username)();
}

export async function authenticate(): Promise<UserDetails> {
	return await eel.authenticate()();
}

export async function isUser(user: string) {
	return await eel.startChat(user)();
}

export async function loadData(): Promise<Contacts> {
	return await eel.loadData()();
}

export async function getMessages(contact: string): Promise<Message[]> {
	return await eel.getMessages(contact)();
}

export async function sendMessage(message: Message) {
	return await eel.sendMessage(message)();
}

export async function deleteChat() {
	eel.deleteChat();
}

export async function makeContact(login: boolean) {
	eel.makeContact(login);
}

export async function startGroup() { }
export async function joinGroup() { }
export async function LeaveGroup() { }

eel.expose(setOnline, "setOnline");
function setOnline(status: boolean) {
	online.set(status ? ONLINE.TRUE : ONLINE.FALSE);
}


eel.expose(updateUI, "updateUI");
function updateUI(type: DATA, sender: string, data) {
	update.set({ type, sender, data });
}


export function formatTag(name: string, tag: number) {
	return `${name}#` + `${tag}`.padStart(4, "0");
}

export const global: Global = {
	username: null,
};