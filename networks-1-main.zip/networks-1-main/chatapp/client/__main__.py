from sys import argv

from .client.Client import Client

ip = "192.168.0.150"
port = 42069
clientPort = None

for i, arg in enumerate(argv, 1):
	if arg == "-h" and len(argv) > i:
		ip = argv[i]
	elif arg == "-p" and len(argv) > i:
		port = int(argv[i])
	elif arg == "-c" and len(argv) > i:
		clientPort = int(argv[i])

client = Client(ip, port, clientPort)
client.start()