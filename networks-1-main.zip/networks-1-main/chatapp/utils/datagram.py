from json import loads, dumps
from math import floor
from time import time
from typing import Union
from zlib import adler32

class Request:
	"""
	A class representing a request sent to the client or the server
	---------------------------------------------------------------
	A request is a packet sent by the server or the client that is not a response to something the
	other sent.

	### Arguments
	`command?: "AUTH" | "CTRL" | "DATA"` - The type of request.
	`type: int`: The request type for the given

	**kwargs are:
	`seq: int` - The sequence number of the Request
	`sent: int` - When the request was sent
	`recipient: string` - Who the request is being sent to. Only for Data requests to the server
	`sender: string` - Who the request is from. Only for data requests to the client
	`body: str` - The body of the request
	"""
	def __init__(this, command: str=None, typ: int=None, **kwargs: "dict[str, Union[str, int]]"):
		this.corrupt = command not in ["AUTH", "CTRL", "DATA"]
		this.command = command
		this.header: dict[str, Union[str, int]] = {
			"type": typ,
			"seq": kwargs.get("seq"),
			"time": None,
		}
		if command == "DATA":
			this.header["sent"] = kwargs.get("sent")
			this.header["recipient"] = kwargs.get("recipient")
		if command == "AUTH" or command == "DATA":
			this.header["sender"] = kwargs.get("sender")
		this.body = kwargs.get("body")


	def encode(this):
		"""
		Encode this request as bytes with a checksum

		`Returns: bytes` - The byte representation of this request
		"""
		# Unix time in the same format used by JavaScript
		this.header["time"] = floor(time()*1000)
		if this.command == "DATA" and this.header["sent"] == None:
			this.header["sent"] = this.header["time"]
		packet = dumps({"command": this.command, "header": this.header, "body": this.body}).encode()
		return str(adler32(packet)).encode() + b"#" + packet
	
	def __str__(this):
		if not this.corrupt:
			return f"{{'command': {this.command}, 'header': {this.header}, 'body': {this.body}}}"
		return "{}"

	def populate(this, command: str, header: dict, body: str):
		"""
		Populate a request with existing command header and body

		### Arguments
		`command: "AUTH" | "CTRL" | "DATA"` - The type of request.
		`header: dict` - The request header
		`body: dict` - The request body
		"""
		this.corrupt = command not in ["AUTH", "CTRL", "DATA"]
		this.command = command
		this.header = header
		this.body = body
		return this

class Response:
	"""
	A class representing a response sent to the client or the server
	----------------------------------------------------------------
	As the name suggests responses are only sent on the receipt of a request.

	### Arguments
	`status: STATUS` - The status of the message this is a response for.
	`seq: int` - The sequence number of the message this is a response for.
	`body?: str` - Any additional information required by the type of request this is a response for.
	"""
	def __init__(this, status: int=None, seq: int = None, body: str = None):
		this.corrupt = True
		try:
			this.corrupt: bool = status < 0 or status > 7
		except: pass
		this.status = status
		this.header: dict[str, int] = {
			"seq": seq,
			"time": None,
		}
		this.body = body

	def encode(this):
		"""
		Encode this response as bytes with a checksum

		`Returns: bytes` - The byte representation of this response
		"""
		# Unix time in the same format used by JavaScript
		this.header["time"] = floor(time()*1000)
		packet = dumps({"status": this.status, "header": this.header, "body": this.body}).encode()
		return str(adler32(packet)).encode() + b"#" + packet
	
	def __str__(this):
		if not this.corrupt:
			return f"{{'status': {this.status}, 'header': {this.header}, 'body': {this.body}}}"
		return "{}"

def decode(data: bytes):
	"""
	Convert a string of bytes to a response or a request

	### Arguments
	`data: bytes` - The bytes to convert

	`Returns: Request | Response`
	"""
	string: str = data.decode()
	msgHash = string[0:string.find("#")]
	msgBytes = string[string.find("#")+1:].encode()
	if (msgHash == str(adler32(msgBytes))):
		msg: dict = loads(msgBytes)
		if "command" in msg:
			result = Request().populate(msg["command"], msg["header"], msg["body"])
		else:
			result = Response(msg["status"], msg["header"]["seq"], msg["body"])
		return result
	return Response()

# These classes are used like enums. I didn't want to use the enums from python 3.10 because 3.10 is too new

class STATUS:
	OK = 0
	BAD_REQUEST = 1
	OUT_OF_SYNC = 2
	DENIED = 3
	NOT_FOUND = 4
	NO_AUTH = 5
	TIME_OUT = 6
	OFFLINE = 7

# Auth messages have the sender field in the header
class AUTH:
	SIGNUP = 0
	LOGIN = 1

class CTRL:
	START_CHAT = 0
	START_GROUP = 1
	JOIN_GROUP = 2
	LEAVE_GROUP = 3
	LOGOUT = 4

# Data messages have the recipient & sent fields in the header
class DATA:
	MSG = 0
	RECEIVED = 1
	READ = 2

# These are the different states a message can have, indicated in the UI with a clock, single tick,
# double tick and blue tick
class MSG:
	UNSENT = 0
	SENT = 1
	RECEIVED = 2
	READ = 3