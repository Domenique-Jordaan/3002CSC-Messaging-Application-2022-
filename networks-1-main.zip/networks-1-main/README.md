# CSC3002F Networks Assignment 1
This is a chat app using UDP on the transport layer, with a custom protocol on the application layer taking care of things like verifying message intgrity, ensuring messages have reached their destination etc.
Created by DVDMIK001, JRDDOM002 and MTNMIC001.
# Dev
All the network code is written in python, but the UI is made with Svelte using Typescript, transpiled to JavaScript.
Before running this application you need to install a dependancy called eel, used to enable the use of web technologies (HTML, CSS, JS) for the GUI.
Assuming you have python 3 installed run the following command in the root directory:
```
pip install -r requirements.txt
```
**Note**: I have commited the built js and css files for the GUI so you do not have to install node and the required packages to transpile the Svelte in order to run the application. If you do wish to transpile it yourself, make sure you have Nodejs v16+ installed, navigate to `chatapp/client/interface` and run
```
npm ci
```
Once that is complete run
```bash
npm run build
```
## Client
Once you have installed the dependancies you can start the client by running `py -m chatapp.client` from the root directory.

The client has 3 command line parameters, which can be applied in any order:
- `-h <server ip>`: If you do not specify a server ip it will default to 192.168.0.150, my home ip address. This won't work.
- `-p <server port>`: If you do not specify a server port it will default to 42069.
- `-c <client port>`: If you are running more than one client on the same device you need to specify a recieving port for one of them, otherwise they will try to use the same one and fail to run. specifying a different recieving port will also tell the program to store your user data in a seperate folder, otherwise the second client would use the first client's data.

**Example**
```bash
py -m chatapp.client -h 000.000.0.000 -p 12000 -c 13000
```
## Server
You can start the server by running `py -m chatapp.server [server_ip, port_num]` from the root directory. If you do not specify a server ip and port number they will default to 192.168.0.150 and port 42069. This will not work on your device unless you happen to have the same IP address I do.

**Example**
```bash
py -m chatapp.server 000.000.0.000 12000
```